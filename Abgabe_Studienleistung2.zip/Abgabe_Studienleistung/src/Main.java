package Main;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;



public class Main {
    static Connection Connex;   // unten initialisierbar wg. nötigem try-Block
// Jeweils eigene (nicht-statische) Connection-Instanzen dann sinnvoll, wenn mehrere
// unabhängige/parallele Zugriffe stattfinden sollen (s. Auskommentierungen unten)

    // Hilfsfunktionen für Ergebnis-Ausgabe (HD = true, wenn Header auszugeben)
    static List<String> ResultToList(ResultSet RS, boolean HD)
    {
        List<String> SL = new ArrayList<>();
        StringBuilder SB = new StringBuilder();
        try
        {
            ResultSetMetaData Meta = RS.getMetaData();
            int N = Meta.getColumnCount();

            // Headerzeile
            if (HD)
            {
                for (int I = 1; I <= N; I++)   // über alle Header-Spalten
                    SB.append(Meta.getColumnLabel(I).toUpperCase()).append("\t");
                SL.add(SB.toString());
            }
            // Datenzeilen
            while (RS.next())                   // über alle Daten-Zeilen
            {
                SB.setLength(0);
                for (int I = 1; I <= N; I++)    // über alle Daten-Spalten
                {
                    SB.append(RS.getObject(I));
                    if (I < N) SB.append('\t');
                }
                SL.add(SB.toString());
            }
        }
        catch (SQLException E)
        {
            System.out.println("Exception: " + E.getMessage());
        }
        return SL;
    }
    static String ResultToString(ResultSet RS)
    {
        return ResultToString(RS, false);
    }
    static String ResultToString(ResultSet RS, boolean HD)
    {
        List<String> RL = ResultToList(RS, HD);
        return String.join(System.lineSeparator(), RL);
    }
    static void StructureDB() {
        try {
            Statement Stmt = Connex.createStatement();
            int Result;
            // Table Sorte: (CoffeeID | Bohne | Herkunftsland)
            Result = Stmt.executeUpdate
                    ("DROP TABLE IF EXISTS Sorte CASCADE");
            Result = Stmt.executeUpdate
                    ("""
                            CREATE TABLE Sorte
                            (CoffeeID integer UNIQUE NOT NULL PRIMARY KEY,
                            Bohne text NOT NULL,
                            Herkunftsland text NOT NULL);""");

            // Table Milchsorte: (MilkID | Name | Ursprung | Kalorien)
            Result = Stmt.executeUpdate
                    ("DROP TABLE IF EXISTS Milchsorte CASCADE");
            Result = Stmt.executeUpdate
                    ("""
                            CREATE TABLE Milchsorte
                            (MilkID integer UNIQUE NOT NULL PRIMARY KEY,
                            Name text NOT NULL,
                            Ursprung text NOT NULL,
                            Kalorien integer NOT NULL);""");

            // Table Getraenk: (GetraenkID | Getraenkename)
            Result = Stmt.executeUpdate
                    ("DROP TABLE IF EXISTS Getraenk CASCADE");
            Result = Stmt.executeUpdate
                    ("""
                            CREATE TABLE Getraenk
                            (Getraenkname text UNIQUE NOT NULL PRIMARY KEY,
                             EspressoShots integer NOT NULL,
                             Kaffeemenge integer NOT NULL);""");

            // Table Zubereitung: ( Getraenkname | Wasser | Milch )
            Result = Stmt.executeUpdate
                    ("DROP TABLE IF EXISTS Zubereitung CASCADE");
            Result = Stmt.executeUpdate
                    ("""
                            CREATE TABLE Zubereitung
                            (Getraenkname text UNIQUE NOT NULL REFERENCES Getraenk,
                            Wassermenge integer NOT NULL,
                            Milchmenge integer NOT NULL);""");

            // Table FertigesGetraenk: ( Getraenkname | CoffeeID | MilkID )
            Result = Stmt.executeUpdate
                    ("DROP TABLE IF EXISTS FertigesGetraenk CASCADE");
            Result = Stmt.executeUpdate
                    ("""
                            CREATE TABLE FertigesGetraenk
                            (CoID integer UNIQUE NOT NULL PRIMARY KEY,
                            Getraenkname text NOT NULL REFERENCES Getraenk,
                            CoffeeID integer NOT NULL REFERENCES Sorte,
                            MilkID integer NOT NULL REFERENCES Milchsorte);""");

            // Table Kaffeetrinker: (ID | Name des Kaffeetrinkers | Getraenkname)
            Result = Stmt.executeUpdate
                    ("DROP TABLE IF EXISTS Kaffeetrinker CASCADE");
            Result = Stmt.executeUpdate
                    ("""
                            CREATE TABLE Kaffeetrinker
                            (ID integer UNIQUE NOT NULL PRIMARY KEY,
                            KTName text NOT NULL,
                            Getraenkname text NOT NULL REFERENCES Getraenk);""");

            Stmt.close();
        } catch (SQLException E) {
            System.out.println("Exception: " + E.getMessage());
        }
    }

        static void UpdateDB()
        {
            try {
                Statement Stmt = Connex.createStatement();
                int Result;

                //Sorte
                Result = Stmt.executeUpdate("DELETE FROM Sorte");
                Stmt.addBatch("INSERT INTO Sorte VALUES(0, 'Arabica', 'Guatemala')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(1, 'Robusta', 'Brasilia')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(2, 'Liberica', 'Philippinen')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(3, 'Excelsa', 'Tschad')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(4, 'Stenophylla', 'Columbia')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(5, 'Arabica', 'Brasilia')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(6, 'Arabica', 'Columbia')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(7, 'Kona', 'Hawaii')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(8, 'Arabica', 'Ethiopia')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(9, 'Robusta', 'Vietnam')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(10, 'Robusta', 'Westafrica')");

                Stmt.executeBatch();

                //Michsorte
                Result = Stmt.executeUpdate("DELETE FROM Milchsorte");
                Stmt.addBatch("INSERT INTO Milchsorte VALUES(0, 'Kuhmilch', 'vegetarisch', '64')");
                Stmt.addBatch("INSERT INTO Milchsorte VALUES(1, 'Mandelmilch', 'vegan', '24')");
                Stmt.addBatch("INSERT INTO Milchsorte VALUES(2, 'Reismilch', 'vegan', '49')");
                Stmt.addBatch("INSERT INTO Milchsorte VALUES(3, 'Sojamilch', 'vegan', '52')");
                Stmt.addBatch("INSERT INTO Milchsorte VALUES(4, 'Ziegenmilch', 'vegetarisch', '69')");
                Stmt.addBatch("INSERT INTO Milchsorte VALUES(5, 'Hafermilch', 'vegan', '54')");
                Stmt.addBatch("INSERT INTO Milchsorte VALUES(6, 'OhneMilch', 'vegan', '0')");
                Stmt.executeBatch();

                //Getränk
                Result = Stmt.executeUpdate("DELETE FROM Getraenk");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Cappuccino', '1', '9')");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Espresso', '1', '7')");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Espresso Macchiato', '1', '7')");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Americano', '2', '14')");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Latte Macchiato', '1', '9')");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Milchkaffee', '1', '9')");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Espresso Doppio', '2', '18')");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Ristretto', '1', '7')");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Cafe Creme', '1', '7')");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Flat White', '2', '14')");
                Stmt.executeBatch();

                // Art der Zubereitung
                Result = Stmt.executeUpdate("DELETE FROM Zubereitung");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Cappuccino', '25', '120')");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Espresso', '25', '0')");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Espresso Macchiato', '25', '5')");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Americano', '150', '0')");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Latte Macchiato', '30', '210')");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Milchkaffee', '120', '120')");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Espresso Doppio', '60', '0')");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Ristretto', '15', '0')");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Cafe Creme', '125', '0')");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Flat White', '60', '100')");
                Stmt.executeBatch();

                // Art der FertigesGetraenk
                Result = Stmt.executeUpdate("DELETE FROM FertigesGetraenk");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(,0 'Cappuccino', '0', '0')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(1, 'Cappuccino', '0', '1')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(2, 'Cappuccino', '0', '2')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(3, 'Cappuccino', '0', '3')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(4, 'Cappuccino', '0', '4')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(5, 'Cappuccino', '0', '5')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(6, 'Cappuccino', '1', '0')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(7, 'Cappuccino', '1', '1')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(8, 'Cappuccino', '1', '2')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(9, 'Cappuccino', '1', '3')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(10, 'Cappuccino', '1', '4')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(11, 'Cappuccino', '1', '5')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(12, 'Cappuccino', '5', '0')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(13, 'Cappuccino', '5', '5')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(14, 'Espresso', '0', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(15, 'Espresso', '1', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(16, 'Espresso', '2', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(17, 'Espresso', '3', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(18, 'Espresso', '4', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(19, 'Espresso', '5', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(20, 'Espresso', '6', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(21, 'Espresso', '7', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(22, 'Espresso', '8', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(23, 'Espresso', '9', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(24, 'Espresso', '10', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(25, 'Espresso Macchiato', '0', '0')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(26, 'Espresso Macchiato', '0', '3')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(27, 'Espresso Macchiato', '0', '5')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(28, 'Espresso Macchiato', '1', '0')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(29, 'Espresso Macchiato', '1', '3')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(30, 'Espresso Macchiato', '1', '5')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(31, 'Espresso Macchiato', '5', '0')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(32, 'Espresso Macchiato', '5', '3')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(33, 'Espresso Macchiato', '5', '5')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(34, 'Americano', '0', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(35, 'Americano', '1', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(36, 'Americano', '2', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(37, 'Americano', '3', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(38, 'Americano', '4', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(39, 'Americano', '5', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(40, 'Americano', '6', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(41, 'Americano', '7', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(42, 'Americano', '8', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(43, 'Americano', '9', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(44, 'Americano', '10', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(45, 'Latte Macchiato', '5', '0')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(46, 'Latte Macchiato', '5', '3')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(47, 'Latte Macchiato', '5', '5')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(48, 'Latte Macchiato', '6', '0')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(49, 'Latte Macchiato', '6', '3')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(50, 'Latte Macchiato', '6', '5')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(51, 'Latte Macchiato', '8', '0')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(52, 'Latte Macchiato', '8', '3')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(53, 'Latte Macchiato', '8', '5')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(54, 'Latte Macchiato', '9', '0')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(55, 'Latte Macchiato', '9', '3')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(56, 'Latte Macchiato', '9', '5')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(57, 'Latte Macchiato', '10', '0')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(58, 'Latte Macchiato', '10', '3')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(58, 'Latte Macchiato', '10', '5')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(59,'Milchkaffee', '2', '0')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(60,'Milchkaffee', '2', '1')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(61,'Milchkaffee', '2', '2')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(62,'Milchkaffee', '3', '0')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(63,'Milchkaffee', '3', '1')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(64,'Milchkaffee', '3', '2')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(65, 'Espresso Doppio', '4', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(66, 'Ristretto', '7', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(67, 'Cafe Creme', '0', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(68, 'Cafe Creme', '1', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(69, 'Cafe Creme', '2', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(70, 'Cafe Creme', '3', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(71, 'Cafe Creme', '4', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(72, 'Cafe Creme', '5', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(73, 'Cafe Creme', '6', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(74, 'Cafe Creme', '7', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(75, 'Cafe Creme', '8', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(76, 'Cafe Creme', '9', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(77, 'Cafe Creme', '10', '6')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(78, 'Flat White', '10', '0')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(79, 'Flat White', '10', '3')");
                Stmt.addBatch("INSERT INTO FertigesGetraenk VALUES(80, 'Flat White', '10', '5')");
                Stmt.executeBatch();

                //Name und Getränk des Kaffeetrinkers
                Result = Stmt.executeUpdate("DELETE FROM Kaffeetrinker");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(0, 'Dirk', 'Cappuccino')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(1, 'Guido', 'Espresso')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(2, 'Katha', 'Espresso Macchiato')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(3, 'Barbara', 'Americano')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(4, 'Lisa', 'Latte Macchiato')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(5, 'Lukas', 'Milchkaffee')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(6, 'Antigona', 'Flat White')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(7, 'Gitte', 'Latte Macchiato')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(8, 'Tobias', 'Espresso')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(9, 'Thomas', 'Ristretto')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(10, 'Susanne', 'Milchkaffee')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(11, 'Daniel', 'Espresso Doppio')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(12, 'Karin', 'Americano')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(13, 'Caro', 'Latte Macciato')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(14, 'Susi', 'Espresso Macchiato')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(15, 'Carina', 'Cappuccino')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(16, 'Paulina', 'Flat White')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(17, 'Franzi', 'Cappuccino')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(18, 'Micha', 'Americano')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(19, 'Swantje', 'Ristretto')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(20, 'Sabrina', 'Milchkaffee')");
                Stmt.executeBatch();

                Stmt.close();
            }
            catch (SQLException E) {
                System.out.println("Exception: " + E.getMessage());
            }
        }
    static void QueryAll() {
        try {
            Statement stmt = Connex.createStatement();
            ResultSet RS;

            System.out.println("SORTE");
            RS = stmt.executeQuery("SELECT * FROM Sorte");
            System.out.println(ResultToString(RS));
            RS.close();

            System.out.println("MILCHSORTE");
            RS = stmt.executeQuery("SELECT * FROM Milchsorte");
            System.out.println(ResultToString(RS));
            RS.close();

            System.out.println("GETRAENK");
            RS = stmt.executeQuery("SELECT * FROM Getraenk");
            System.out.println(ResultToString(RS));
            RS.close();

            System.out.println("ZUBEREITUNG");
            RS = stmt.executeQuery("SELECT * FROM Zubereitung");
            System.out.println(ResultToString(RS));
            RS.close();

            System.out.println("FERTIGESGETRAENK");
            RS = stmt.executeQuery("SELECT * FROM FertigesGetraenk");
            System.out.println(ResultToString(RS));
            RS.close();

            System.out.println("KAFFEETRINKER");
            RS = stmt.executeQuery("SELECT * FROM Kaffeetrinker");
            System.out.println(ResultToString(RS));
            RS.close();

            stmt.close();
        } catch(SQLException E) {
            System.out.println("QueryAll error: " + E.getMessage());
        }
    }
    static void QueryDB_1()
    {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;       // Subinterface RowSet mit zusätzlichen Methoden
            RS = Stmt.executeQuery( "SELECT Getraenkname FROM Getraenk");
            System.out.println("List of all coffees");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E) {
            System.out.println("Query 1 error " + E.getMessage());
        }
    }
    static void QueryDB_2()
    {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;
            RS = Stmt.executeQuery( "SELECT DISTINCT Bohne FROM Sorte WHERE Herkunftsland LIKE 'B%' OR Herkunftsland LIKE 'C%' OR Herkunftsland LIKE 'W%'");
            System.out.println("All beans which country of origin starts with b or c or w");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E) {
            System.out.println("Query 2 error " + E.getMessage());
        }
    }

    static void QueryDB_3()
    {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;
            RS = Stmt.executeQuery( "SELECT Getraenkname FROM Zubereitung WHERE Milchmenge >'0'");
            System.out.println("All coffees which are made with milk");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E){
         System.out.println("Query 3 error " + E.getMessage());
        }
    }

    static void QueryDB_4()
    {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;
            RS = Stmt.executeQuery( "SELECT KTName, Getraenkname FROM Kaffeetrinker WHERE Getraenkname LIKE 'L%' AND KTName LIKE 'L%'");
            System.out.println("All coffeedrinkers whose name start with l and drink starts with l");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E) {
            System.out.println("Query 4 error " + E.getMessage());
        }
    }

    static void QueryDB_5()
    {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;
            RS = Stmt.executeQuery( "SELECT Name FROM Milchsorte WHERE Kalorien BETWEEN '20' AND '53' AND Ursprung = 'vegan'");
            System.out.println("All kinds of milk with a calorie value between 20 and 53 cal that are vegan");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E) {
            System.out.println("Query 5 error " + E.getMessage());
        }
    }

   static void QueryDB_6()
   {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;
            RS = Stmt.executeQuery( "SELECT Getraenkname FROM Getraenk ORDER BY Kaffeemenge ASC");
            System.out.println("All coffees listed by its amount of coffee");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E) {
            System.out.println("Query 6 error " + E.getMessage());
        }
    }


    static void QueryDB_7()
    {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;
            RS = Stmt.executeQuery( "SELECT Kaffeetrinker.* FROM Kaffeetrinker WHERE NOT EXISTS(SELECT Getraenk.Getraenkname FROM Getraenk WHERE Getraenk.Getraenkname = Kaffeetrinker.Getraenkname)");
            System.out.println("All coffees that are not in ");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E) {
            System.out.println("Query 7 error " + E.getMessage());
        }
    }

    static void QueryDB_8()
    {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;
            RS = Stmt.executeQuery( "SELECT Kaffeetrinker.KTName, Zubereitung.Getraenkname,  Kaffeetrinker.ID FROM Kaffeetrinker INNER JOIN Zubereitung ON Kaffeetrinker.Getraenkname = Zubereitung.Getraenkname");
            System.out.println("All coffees ");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E) {
            System.out.println("Query 8 error " + E.getMessage());
        }
    }
    static void QueryDB_9()
    {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;
            RS = Stmt.executeQuery( "INSERT INTO Kaffeetrinker (KaffeetID, KTName, Getraenkname) VALUES (ID, KTName, Getraenkname)");
            System.out.println("All coffees ");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E) {
            System.out.println("Query 9 error " + E.getMessage());
        }
    }

    static void QueryDB_10()
    {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;
            RS = Stmt.executeQuery( "SELECT Getraenk.Getraenkname, FertigesGetraenk.CoID FROM Getraenk FULL OUTER JOIN FertigesGetraenk ON Getraenk.Getraenkname=FertigesGetraenk.Getraenkname");
            System.out.println("All coffeesnames ");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E) {
            System.out.println("Query 10 error " + E.getMessage());
        }
    }

    public static void main(String[] args) {
        try
        { Class.forName("org.postgresql.Driver"); }
        catch (ClassNotFoundException E)
        { System.out.println("Exception: " + E.getMessage()); }

        try
        {
            // Todo: Hier evtl. eigenes Passwort einfügen (statt "blubb")!
            Connex = DriverManager.getConnection  // wenn erste PG-Installation
                    ("jdbc:postgresql:Coffee", "postgres", "blubb");
            /*Connex = DriverManager.getConnection    // nur wenn weitere PG-Updates
                ("jdbc:postgresql://localhost:5433/Comedies", "postgres", "blubb");*/

            StructureDB();
            UpdateDB();
            QueryAll();
            QueryDB_1();
            QueryDB_2();
            QueryDB_3();
            QueryDB_4();
            QueryDB_5();
            QueryDB_6();
            QueryDB_7();
            QueryDB_8();
            QueryDB_9();
            QueryDB_10();
            
            Connex.close();
        }
        catch (SQLException E)
        { System.out.println("Connection error " + E.getMessage()); }

        }
}