package Main;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;



public class Main {
    static Connection Connex;   // unten initialisierbar wg. nötigem try-Block
// Jeweils eigene (nicht-statische) Connection-Instanzen dann sinnvoll, wenn mehrere
// unabhängige/parallele Zugriffe stattfinden sollen (s. Auskommentierungen unten)

    // Hilfsfunktionen für Ergebnis-Ausgabe (HD = true, wenn Header auszugeben)
    static List<String> ResultToList(ResultSet RS, boolean HD)
    {
        List<String> SL = new ArrayList<>();
        StringBuilder SB = new StringBuilder();
        try
        {
            ResultSetMetaData Meta = RS.getMetaData();
            int N = Meta.getColumnCount();

            // Headerzeile
            if (HD)
            {
                for (int I = 1; I <= N; I++)   // über alle Header-Spalten
                    SB.append(Meta.getColumnLabel(I).toUpperCase()).append("\t");
                SL.add(SB.toString());
            }
            // Datenzeilen
            while (RS.next())                   // über alle Daten-Zeilen
            {
                SB.setLength(0);
                for (int I = 1; I <= N; I++)    // über alle Daten-Spalten
                {
                    SB.append(RS.getObject(I));
                    if (I < N) SB.append('\t');
                }
                SL.add(SB.toString());
            }
        }
        catch (SQLException E)
        {
            System.out.println("Exception: " + E.getMessage());
        }
        return SL;
    }
    static String ResultToString(ResultSet RS)
    {
        return ResultToString(RS, false);
    }
    static String ResultToString(ResultSet RS, boolean HD)
    {
        List<String> RL = ResultToList(RS, HD);
        return String.join(System.lineSeparator(), RL);
    }
    static void StructureDB() {
        try {
            Statement Stmt = Connex.createStatement();
            int Result;
            // Table Sorte: (CoffeeID | Bohne | Herkunftsland)
            Result = Stmt.executeUpdate
                    ("DROP TABLE IF EXISTS Sorte CASCADE");
            Result = Stmt.executeUpdate
                    ("""
                            CREATE TABLE Sorte
                            (CoffeeID integer UNIQUE NOT NULL PRIMARY KEY,
                            Bohne text NOT NULL,
                            Herkunftsland text NOT NULL);""");

            // Table Milchsorte: (MilkID | Name | Ursprung | Kalorien)
            Result = Stmt.executeUpdate
                    ("DROP TABLE IF EXISTS Milchsorte CASCADE");
            Result = Stmt.executeUpdate
                    ("""
                            CREATE TABLE Milchsorte
                            (MilkID integer UNIQUE NOT NULL PRIMARY KEY,
                            Name text NOT NULL,
                            Ursprung text NOT NULL,
                            Kalorien integer NOT NULL);""");

            // Table Getraenk: (GetraenkID | Getraenkename)
            Result = Stmt.executeUpdate
                    ("DROP TABLE IF EXISTS Getraenk CASCADE");
            Result = Stmt.executeUpdate
                    ("""
                            CREATE TABLE Getraenk
                            (Getraenkname text UNIQUE NOT NULL PRIMARY KEY,
                             EspressoShots integer NOT NULL,
                             Kaffeemenge integer NOT NULL);""");

            // Table Zubereitung: ( Getraenkname | CoffeeID | MilkID )
            Result = Stmt.executeUpdate
                    ("DROP TABLE IF EXISTS Zubereitung CASCADE");
            Result = Stmt.executeUpdate
                    ("""
                            CREATE TABLE Zubereitung
                            (Getraenkname text UNIQUE NOT NULL REFERENCES Getraenk,
                            Wassermenge integer NOT NULL,
                            Milchmenge integer NOT NULL);""");


            // Table Kaffeetrinker: (ID | Name des Kaffeetrinkers | Getraenkname)
            Result = Stmt.executeUpdate
                    ("DROP TABLE IF EXISTS Kaffeetrinker CASCADE");
            Result = Stmt.executeUpdate
                    ("""
                            CREATE TABLE Kaffeetrinker
                            (ID integer UNIQUE NOT NULL PRIMARY KEY,
                            KTName text NOT NULL,
                            Getraenkname text NOT NULL REFERENCES Getraenk);""");

            Stmt.close();
        } catch (SQLException E) {
            System.out.println("Exception: " + E.getMessage());
        }
    }

        static void UpdateDB()
        {
            try {
                Statement Stmt = Connex.createStatement();
                int Result;

                //Sorte
                Result = Stmt.executeUpdate("DELETE FROM Sorte");
                Stmt.addBatch("INSERT INTO Sorte VALUES(0, 'Arabica', 'Guatemala')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(1, 'Robusta', 'Brasilia')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(2, 'Liberica', 'Philippinen')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(3, 'Excelsa', 'Tschad')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(4, 'Stenophylla', 'Columbia')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(5, 'Arabica', 'Brasilia')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(6, 'Arabica', 'Columbia')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(7, 'Kona', 'Hawaii')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(8, 'Arabica', 'Ethiopia')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(9, 'Robusta', 'Vietnam')");
                Stmt.addBatch("INSERT INTO Sorte VALUES(10, 'Robusta', 'Westafrica')");

                Stmt.executeBatch();

                //Michsorte
                Result = Stmt.executeUpdate("DELETE FROM Milchsorte");
                Stmt.addBatch("INSERT INTO Milchsorte VALUES(0, 'Kuhmilch', 'vegetarisch', '64')");
                Stmt.addBatch("INSERT INTO Milchsorte VALUES(1, 'Mandelmilch', 'vegan', '24')");
                Stmt.addBatch("INSERT INTO Milchsorte VALUES(2, 'Reismilch', 'vegan', '49')");
                Stmt.addBatch("INSERT INTO Milchsorte VALUES(3, 'Sojamilch', 'vegan', '52')");
                Stmt.addBatch("INSERT INTO Milchsorte VALUES(4, 'Ziegenmilch', 'vegetarisch', '69')");
                Stmt.addBatch("INSERT INTO Milchsorte VALUES(5, 'Hafermilch', 'vegan', '54')");
                Stmt.addBatch("INSERT INTO Milchsorte VALUES(6, 'OhneMilch', 'vegan', '0')");
                Stmt.executeBatch();

                //Getränk
                Result = Stmt.executeUpdate("DELETE FROM Getraenk");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Cappuccino', '1', '9')");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Espresso', '1', '7')");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Espresso Macchiato', '1', '7')");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Americano', '2', '14')");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Latte Macchiato', '1', '9')");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Milchkaffee', '1', '9')");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Espresso Doppio', '2', '18')");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Ristretto', '1', '7')");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Cafe Creme', '1', '7')");
                Stmt.addBatch("INSERT INTO Getraenk VALUES('Flat White', '2', '14')");
                Stmt.executeBatch();

                // Art der Zubereitung
                Result = Stmt.executeUpdate("DELETE FROM Zubereitung");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Cappuccino', '25', '120')");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Espresso', '25', '0')");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Espresso Macchiato', '25', '5')");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Americano', '150', '0')");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Latte Macchiato', '30', '210')");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Milchkaffee', '120', '120')");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Espresso Doppio', '60', '0')");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Ristretto', '15', '0')");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Cafe Creme', '125', '0')");
                Stmt.addBatch("INSERT INTO Zubereitung VALUES('Flat White', '60', '100')");
                Stmt.executeBatch();

                //Name und Getränk des Kaffeetrinkers
                Result = Stmt.executeUpdate("DELETE FROM Kaffeetrinker");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(0, 'Dirk', 'Cappuccino')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(1, 'Guido', 'Espresso')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(2, 'Katha', 'Espresso Macchiato')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(3, 'Barbara', 'Americano')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(4, 'Lisa', 'Latte Macchiato')");
                Stmt.addBatch("INSERT INTO Kaffeetrinker VALUES(5, 'Lukas', 'Milchkaffee')");
                Stmt.executeBatch();

                Stmt.close();
            }
            catch (SQLException E) {
                System.out.println("Exception: " + E.getMessage());
            }
        }
    static void QueryAll() {
        try {
            Statement stmt = Connex.createStatement();
            ResultSet RS;

            System.out.println("SORTE");
            RS = stmt.executeQuery("SELECT * FROM Sorte");
            System.out.println(ResultToString(RS));
            RS.close();

            System.out.println("MILCHSORTE");
            RS = stmt.executeQuery("SELECT * FROM Milchsorte");
            System.out.println(ResultToString(RS));
            RS.close();

            System.out.println("GETRAENK");
            RS = stmt.executeQuery("SELECT * FROM Getraenk");
            System.out.println(ResultToString(RS));
            RS.close();

            System.out.println("ZUBEREITUNG");
            RS = stmt.executeQuery("SELECT * FROM Zubereitung");
            System.out.println(ResultToString(RS));
            RS.close();

            System.out.println("KAFFEETRINKER");
            RS = stmt.executeQuery("SELECT * FROM Kaffeetrinker");
            System.out.println(ResultToString(RS));
            RS.close();

            stmt.close();
        } catch(SQLException E) {
            System.out.println("QueryAll error: " + E.getMessage());
        }
    }
    static void QueryDB_1()
    {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;       // Subinterface RowSet mit zusätzlichen Methoden
            RS = Stmt.executeQuery( "SELECT Getraenkname FROM Getraenk");
            System.out.println("List of all coffees");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E) {
            System.out.println("Query 1 error " + E.getMessage());
        }
    }
    static void QueryDB_2()
    {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;
            RS = Stmt.executeQuery( "SELECT DISTINCT Bohne FROM Sorte WHERE Herkunftsland LIKE 'B%' OR Herkunftsland LIKE 'C%' OR Herkunftsland LIKE 'W%'");
            System.out.println("All beans which country of origin starts with b or c or w");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E) {
            System.out.println("Query 2 error " + E.getMessage());
        }
    }

    static void QueryDB_3()
    {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;
            RS = Stmt.executeQuery( "SELECT Getraenkname FROM Zubereitung WHERE Milchmenge >'0'");
            System.out.println("All coffees which are made with milk");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E){
         System.out.println("Query 3 error " + E.getMessage());
        }
    }

    static void QueryDB_4()
    {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;
            RS = Stmt.executeQuery( "SELECT KTName, Getraenkname FROM Kaffeetrinker WHERE Getraenkname LIKE 'L%' AND KTName LIKE 'L%'");
            System.out.println("All coffeedrinkers whose name start with l and drink starts with l");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E) {
            System.out.println("Query 4 error " + E.getMessage());
        }
    }

    static void QueryDB_5()
    {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;
            RS = Stmt.executeQuery( "SELECT Name FROM Milchsorte WHERE Kalorien BETWEEN '20' AND '53' AND Ursprung = 'vegan'");
            System.out.println("All kinds of milk with a calorie value between 20 and 53 cal that are vegan");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E) {
            System.out.println("Query 5 error " + E.getMessage());
        }
    }

   static void QueryDB_6()
   {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;
            RS = Stmt.executeQuery( "SELECT Getraenkname FROM Getraenk ORDER BY Kaffeemenge ASC");
            System.out.println(ResultToString(RS));
            System.out.println("All coffees ordered by its amount of coffee");
            RS.close();

            Stmt.close();
        }
        catch (SQLException E) {
            System.out.println("Query 6 error " + E.getMessage());
        }
    }


    static void QueryDB_7()
    {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;
            RS = Stmt.executeQuery( "SELECT ORIGIN FROM Sorte");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E) {
            System.out.println("Query 7 error " + E.getMessage());
        }
    }

    static void QueryDB_8()
    {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;
            RS = Stmt.executeQuery( "SELECT ORIGIN FROM Sorte");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E) {
            System.out.println("Query 8 error " + E.getMessage());
        }
    }
    static void QueryDB_9()
    {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;
            RS = Stmt.executeQuery( "SELECT ORIGIN FROM Sorte");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E) {
            System.out.println("Query 9 error " + E.getMessage());
        }
    }

    static void QueryDB_10()
    {
        try
        {
            Statement Stmt = Connex.createStatement();
            ResultSet RS;
            RS = Stmt.executeQuery( "SELECT ORIGIN FROM Sorte");
            System.out.println(ResultToString(RS));
            RS.close();

            Stmt.close();
        }
        catch (SQLException E) {
            System.out.println("Query 10 error " + E.getMessage());
        }
    }

    public static void main(String[] args) {
        try
        { Class.forName("org.postgresql.Driver"); }
        catch (ClassNotFoundException E)
        { System.out.println("Exception: " + E.getMessage()); }

        try
        {
            // Todo: Hier evtl. eigenes Passwort einfügen (statt "blubb")!
            Connex = DriverManager.getConnection  // wenn erste PG-Installation
                    ("jdbc:postgresql:Coffee", "postgres", "blubb");
            /*Connex = DriverManager.getConnection    // nur wenn weitere PG-Updates
                ("jdbc:postgresql://localhost:5433/Comedies", "postgres", "blubb");*/

            StructureDB();
            UpdateDB();
            QueryAll();
            QueryDB_1();
            QueryDB_2();
            QueryDB_3();
            QueryDB_4();
            QueryDB_5();
            QueryDB_6();

            Connex.close();
        }
        catch (SQLException E)
        { System.out.println("Connection error " + E.getMessage()); }

        }
}